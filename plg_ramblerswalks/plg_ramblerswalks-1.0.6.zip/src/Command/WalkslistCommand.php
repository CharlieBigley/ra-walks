<?php

/**
 * @package     Joomla.Console
 * @subpackage  Onoffbydate
 *
 * @copyright   Copyright (C) 2005 - 2021 Clifford E Ford. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * 16/12/24 CB created from WalksloadCommand
 * 17/12/24 CB return 1 from doExecute
 */

namespace Ramblers\Plugin\System\Ramblerswalks\Command;

\defined('JPATH_PLATFORM') or die;

use Joomla\CMS\Factory;
use Joomla\Console\Command\AbstractCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Exception\InvalidOptionException;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Question\ChoiceQuestion;
use Symfony\Component\Console\Style\SymfonyStyle;
use Ramblers\Component\Ra_tools\Site\Helpers\ToolsHelper;

class WalkslistCommand extends AbstractCommand {

    /**
     * The default command name
     *
     * @var    string
     *
     * @since  4.0.0
     */
    protected static $defaultName = 'ramblerswalks:walkslist';

    /**
     * @var InputInterface
     * @since version
     */
    private $cliInput;

    /**
     * SymfonyStyle Object
     * @var SymfonyStyle
     * @since 4.0.0
     */
    private $ioStyle;

    /**
     * Instantiate the command.
     *
     * @since   4.0.0
     */
    public function __construct() {
        parent::__construct();
    }

    /**
     * Configures the IO
     *
     * @param   InputInterface   $input   Console Input
     * @param   OutputInterface  $output  Console Output
     *
     * @return void
     *
     * @since 4.0.0
     *
     */
    private function configureIO(InputInterface $input, OutputInterface $output) {
        $this->cliInput = $input;
        $this->ioStyle = new SymfonyStyle($input, $output);
    }

    /**
     * Initialise the command.
     *
     * @return  void
     *
     * @since   4.0.0
     */
    protected function configure(): void {

        $help = "<info>%command.name%</info> List summary data about walks
			\nUsage: <info>php %command.full_name%
			\nNo parameters are available</info>";

        $this->setDescription('Called by cron to list summary of walks.');
        $this->setHelp($help);
    }

    /**
     * Internal function to execute the command.
     *
     * @param   InputInterface   $input   The input to inject into the command.
     * @param   OutputInterface  $output  The output to inject into the command.
     *
     * @return  integer  The command exit code
     *
     * @since   4.0.0
     */
    protected function doExecute(InputInterface $input, OutputInterface $output): int {
        $this->configureIO($input, $output);

        $objHelper = new ToolsHelper;

        $sql = 'SELECT COUNT(id) FROM #__ra_walks';
        $this->ioStyle->comment("Total number of walks is " . number_format($objHelper->getValue($sql)));

        $sql = 'SELECT MIN(walk_date) FROM #__ra_walks';
        $this->ioStyle->comment("Earliest walk is for " . $objHelper->getValue($sql));

        $sql = 'SELECT MAX(walk_date) FROM #__ra_walks';
        $this->ioStyle->comment("Latest walk is for " . $objHelper->getValue($sql));

        return 1;
    }

}
