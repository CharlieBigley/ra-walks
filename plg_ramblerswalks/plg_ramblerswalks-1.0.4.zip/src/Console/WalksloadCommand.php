<?php

/**
 * @package     Joomla.Console
 * @subpackage  Onoffbydate
 *
 * @copyright   Copyright (C) 2005 - 2021 Clifford E Ford. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * 11/12/24 CB created from OnoffbydateCommand
 * 17/12/24 CB return 1 from doExecute
 */

namespace Ramblers\Plugin\System\Ramblerswalks\Console;

\defined('JPATH_PLATFORM') or die;

use Joomla\CMS\Factory;
use Joomla\Console\Command\AbstractCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Exception\InvalidOptionException;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Question\ChoiceQuestion;
use Symfony\Component\Console\Style\SymfonyStyle;
use Ramblers\Component\Ra_walks\Site\Helpers\LoadHelper;

class WalksloadCommand extends AbstractCommand {

    /**
     * The default command name
     *
     * @var    string
     *
     * @since  4.0.0
     */
    protected static $defaultName = 'ramblerswalks:walksload';

    /**
     * @var InputInterface
     * @since version
     */
    private $cliInput;

    /**
     * SymfonyStyle Object
     * @var SymfonyStyle
     * @since 4.0.0
     */
    private $ioStyle;

    /**
     * Instantiate the command.
     *
     * @since   4.0.0
     */
    public function __construct() {
        parent::__construct();
    }

    /**
     * Configures the IO
     *
     * @param   InputInterface   $input   Console Input
     * @param   OutputInterface  $output  Console Output
     *
     * @return void
     *
     * @since 4.0.0
     *
     */
    private function configureIO(InputInterface $input, OutputInterface $output) {
        $this->cliInput = $input;
        $this->ioStyle = new SymfonyStyle($input, $output);
    }

    /**
     * Initialise the command.
     *
     * @return  void
     *
     * @since   4.0.0
     */
    protected function configure(): void {
        $this->addArgument('areacode',
                InputArgument::REQUIRED,
                'scope of load');

        $help = "<info>%command.name%</info> Loads walk data from WalksManager feed
			\nUsage: <info>php %command.full_name% areacode
			\nwhere areacode is either ALL for all areas, or a two character area code</info>";

        $this->setDescription('Called by cron to load walks from the WalksManager feed.');
        $this->setHelp($help);
    }

    /**
     * Internal function to execute the command.
     *
     * @param   InputInterface   $input   The input to inject into the command.
     * @param   OutputInterface  $output  The output to inject into the command.
     *
     * @return  integer  The command exit code
     *
     * @since   4.0.0
     */
    protected function doExecute(InputInterface $input, OutputInterface $output): int {
        $this->configureIO($input, $output);

        $areacode = $this->cliInput->getArgument('areacode');
        $this->ioStyle->comment("areacode= {$areacode}");
// validate input
        if (!strtoupper($areacode) == 'ALL') {

        } else {
            if (!strlen($areacode) == 2) {
                $this->ioStyle->error("Invalid area code {$areacode}");
                return 0;
            }
        }
        $loadHelper = new LoadHelper;
        $this->ioStyle->comment("Invoking helper");
        $result = $loadHelper->refresh();
        if ($result) {
            $this->ioStyle->comment('helper finished OK');
        } else {
            $this->ioStyle->error('helper failed');
        }
        if ($loadHelper->error_count > 0) {
            echo '<b>Errors</b><br>';
            foreach ($loadHelper->errors as $error) {
                $this->ioStyle->error($error);
            }
        }
        if ($loadHelper->warning_count > 0) {
            echo '<b>Warnings</b><br>';
            foreach ($loadHelper->warnings as $warning) {
                $this->ioStyle->warning($warning);
            }
        }
        if ($loadHelper->comment_count > 0) {
            echo '<b>Comments</b><br>';
            foreach ($loadHelper->ecomments as $comment) {
                $this->ioStyle->comment($comment);
            }
        }
        return 1;
    }

}
