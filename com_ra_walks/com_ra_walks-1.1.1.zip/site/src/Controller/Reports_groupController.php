<?php

namespace Ramblers\Component\Ra_walks\Site\Controller;

use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Controller\FormController;
use Joomla\CMS\Router\Route;

class Reports_groupController extends FormController {

}
