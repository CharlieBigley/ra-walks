# 2 files in total
# 22/05/23 Created
# 06/08/23 Just two tables
DROP TABLE IF EXISTS `#__ra_walks_audit`;
DROP TABLE IF EXISTS `#__ra_walks`;
#--------------------------------------------------------------------------------
